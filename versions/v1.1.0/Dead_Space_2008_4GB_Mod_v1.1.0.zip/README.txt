DEAD SPACE (2008) - 4GB MOD
Version 1.1.0

WHAT IT DOES

Automatically enables the standard Windows Large Address Aware (LAA) flag on
the original 32-bit Dead Space executable. This lets the game use up to 4 GB of
virtual address space on 64-bit Windows instead of the usual 2 GB limit.

This is an original standalone mod. It does not contain NTCore's 4gb_patch.exe,
does not include a modified Dead Space.exe, and does not require any Vortex
extension update.

VORTEX INSTALL

1. Install the Main File with Vortex.
2. Enable the mod and Deploy Mods.
3. Launch Dead Space normally from EA, Steam, Vortex, or your usual shortcut.

That is all. Do not launch a separate patcher. On the first successful launch,
the game will briefly close and reopen once so Windows can start it with LAA
enabled. Later launches start normally without that extra restart. If the
executable was already LAA, the mod leaves it alone and no restart occurs.

MANUAL INSTALL

Extract every file into the folder containing Dead Space.exe, then launch the
game normally. The automatic first-launch behavior is the same with or without
Vortex.

SAFETY

- Only a valid 32-bit PE executable named exactly Dead Space.exe is accepted.
- A SHA-256-verified backup is created before any target write.
- The exact target file is pinned against concurrent replacement or store edits.
- Only the byte containing the standard LAA bit is changed, flushed, and
  verified afterward.
- During an ordinary first-launch handoff, if patching stops before the write or
  a rollback verifies successfully, the game starts unchanged and a clear error
  explains what happened.
- If the final executable state cannot be proven safe, the mod does not restart
  it. Use Restore or EA/Steam Repair/Verify before trying again.
- Windows may show a standard administrator prompt if the game folder is
  protected.
- Do not set Dead Space, EA, Steam, or their shortcuts to always run as
  administrator. First-time patching intentionally refuses an already-elevated
  game. Launch normally and approve only the mod's narrow one-time prompt.

The backup and manifest are stored beside the game as:

  Dead Space.exe.deadspace-laa.bak
  Dead Space.exe.deadspace-laa.manifest.json

UNINSTALL / RESTORE

While the mod is still installed, double-click:

  Restore Dead Space 4GB Mod.cmd

The restore requires the backup file and proves that the current executable and
backup are an exact one-bit LAA pair. It uses the manifest hashes when the
manifest is valid, but can recover safely if that manifest is missing or
incomplete. It clears the bit and verifies the exact original bytes. After the
success message, disable/remove the mod and Deploy Mods in Vortex, or delete the
installed mod files manually.

If you removed the mod before restoring, use EA App Repair or Steam Verify
Integrity of Game Files to restore Dead Space.exe.

If Dead Space.exe was already LAA before this mod first ran, this mod creates no
backup or manifest and does not claim ownership of that earlier change. Use
Repair/Verify if you want to restore the store executable.

COMPATIBILITY

This mod uses dsound.dll as its normal-launch bootstrap. It conflicts with any
other local dsound.dll unless proxy chaining is deliberately arranged. Other
proxy names such as d3d9.dll and xinput1_3.dll are not replaced.

EA App Repair or Steam file verification may restore the original executable.
If its hash still matches this mod's backup and dsound.dll remains deployed, the
next normal launch applies LAA again. If an actual game update changes the
executable, the old backup will not match and the mod safely refuses to patch.

ANTIVIRUS NOTE

The DLL is unsigned native code whose stated purpose is to back up and modify one
bit in a game executable, then relaunch it. That behavior can trigger heuristic
scanner warnings. Changing the PE header also invalidates any existing digital
signature on Dead Space.exe; Restore or Repair/Verify puts the exact store copy
back. The DLL is not packed or obfuscated.

The separate Source Code archive is for inspection only. It is not required to
install or use the mod. Never download this mod from an untrusted mirror.

TROUBLESHOOTING

The log is stored at:

  %LOCALAPPDATA%\DeadSpace4GBMod\one-dll-bootstrap.log

If the game does not launch after an error, restore with the included command or
use your store's Repair/Verify feature.

If the mod says Dead Space was launched as administrator, turn off "Run this
program as an administrator" for the game/store shortcut and launch normally.

If a real game update changed Dead Space.exe, run Repair/Verify, then move the
old .deadspace-laa.bak and .deadspace-laa.manifest.json files out of the game
folder before launching again. This lets the mod create a backup for the new
executable without overwriting the old one.

RELEASE STATUS

Version 1.1.0 passed the full synthetic integration suite and was confirmed
working through a normal retail game launch. EA App and Steam installations can
still have store-specific differences, so please report any unexpected launch
behavior.

LICENSE

Copyright (c) 2026 Rama2120. Released under the MIT License.
